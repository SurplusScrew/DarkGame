public enum Action
{
    None,
    Jump
}