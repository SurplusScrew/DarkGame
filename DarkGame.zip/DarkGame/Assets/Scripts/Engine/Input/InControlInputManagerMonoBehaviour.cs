﻿using System;
using InControl;
using UnityEngine;

[Serializable]
public struct InputAction {
	public Action action;
	public InputControlType inputControlType;

}
public class InControlInputManagerMonoBehaviour : MonoBehaviour, IInputManager
{
	public InputAction[] inputActions;
	private IInputManager Manager;

	private void Awake()
	{
		Manager = new InControlInputManager(ref inputActions);
	}
	public bool ButtonIsPressed(Action action)
    {
		return Manager.ButtonIsPressed(action);
	}
	public Vector2 GetMoveVector()
	{
		return Manager.GetMoveVector();
	}
	public Vector2 GetLookVector()
	{
		return Manager.GetLookVector();
	}
}

public class InControlInputManager : IInputManager
{
	public InputAction[] inputActions;
	public IInControlInputService inputService;

	public InControlInputManager(ref InputAction[] actions)
	{
		inputActions = actions;
	}
    public bool ButtonIsPressed(Action action)
    {
		foreach(InputAction iAction in inputActions)
		{
			if(iAction.action == action)
			{
				return inputService.GetControlIsDown(iAction.inputControlType);
			}
		}
		return false;
    }

	public Vector2 GetMoveVector()
	{
		return inputService.LeftStick;
	}
	public Vector2 GetLookVector()
	{
		return inputService.RightStick;
	}
}

public interface IInControlInputService
{
	Vector2 LeftStick
	{
		get;
	}
	Vector2 RightStick
	{
		get;
	}

	bool GetControlIsDown(InputControlType action);
}

public class InControlInputService
{
	Vector2 LeftStick
	{
		get{
			return InputManager.ActiveDevice.LeftStick.Vector;
		}
	}
	Vector2 RightStick
	{
		get{
			return InputManager.ActiveDevice.RightStick.Vector;
		}
	}
	public bool GetControlIsDown(InputControlType action)
	{
		return InputManager.ActiveDevice.GetControl(action).IsPressed;
	}

}
