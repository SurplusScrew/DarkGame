﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonoBehaviourObjectWrapper<T> : MonoBehaviour
{
	public T Obj{get; protected set;}


}
