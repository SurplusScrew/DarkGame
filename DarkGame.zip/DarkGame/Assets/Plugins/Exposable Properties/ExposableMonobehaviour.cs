﻿using UnityEngine;

public class ExposableMonoBehaviour : MonoBehaviour {}
