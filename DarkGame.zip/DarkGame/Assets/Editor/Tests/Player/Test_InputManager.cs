using UnityEngine.TestTools;
using NSubstitute;
using NUnit.Framework;
using System.Collections;

namespace Tests
{
    public class Test_InputManager
   {
       InControlInputManager manager;
        InputAction[] actions;
        IInControlInputService InputService;

        [SetUp]
        public void setup()
        {
            InputService = Substitute.For<IInControlInputService>();

            actions = new InputAction[]{

                new InputAction{
                    action = Action.Jump,
                    inputControlType = InControl.InputControlType.Action1
                }
            };

            manager = new InControlInputManager(ref actions);
            manager.inputService = InputService;

        }

        [TearDown]
        public void TearDown()
        {
            manager = null;
        }

        [Test]
        public void ButtonIsPressed_InvalidAction_ShouldReturnFalse()
        {
            Assert.IsFalse(manager.ButtonIsPressed(Action.None));
        }

        [Test]
        public void ButtonIsPressed_ValidAction_ShouldReturnTrue()
        {
            InputService.GetControlIsDown(InControl.InputControlType.Action1).Returns(true);
            Assert.IsTrue(manager.ButtonIsPressed(Action.Jump));
        }
    }

}
